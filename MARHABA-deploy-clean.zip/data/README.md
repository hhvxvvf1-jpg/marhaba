Runtime SQLite database and session secret are created here automatically. Do not commit local database files or secrets.
